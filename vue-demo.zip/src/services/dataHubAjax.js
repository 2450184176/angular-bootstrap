import { Message } from 'element-ui';
import axios from './http';

export default {
  async getOriginDataList() {
    const res = await axios.get('https://easy-mock.com/mock/59ab90efe0dc66334199b57b/dataHub/realData');
    if (!res.ok) return Message.error(res.errMsg);
    return {
      data: res.data,
      load: false,
    };
  },
  async getSubData() {
    const res = await axios.post('https://easy-mock.com/mock/59ab90efe0dc66334199b57b/dataHub/mydata');
    if (!res.ok) return Message.error(res.errMsg);
    return {
      data: res.data,
      load: false,
    };
  },
};
