import axios from 'axios';
import { Message, MessageBox } from 'element-ui';
import router from '../router/index';
import store from '../store/index';
import util from '../lib/util';

// axios.defaults.timeout = 60000;
// http request 拦截器
axios.baseURL = {
  systemUrl: '/portal-web-system',
  loginUrl: '/portal-web-system/usermanage/admin/system',
  mcCtrl: '/mc-ctrl',
};
axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
axios.defaults.headers.common['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
axios.interceptors.request.use(
  config => config,
  err => Promise.reject(err),
);
axios.interceptors.response.use(
  (res) => {
    // 取消lid对应的loading
    if (res.data.status === 401) {
      store.commit('clearUserInfo');
      router.replace({
        path: '/',
      });
      return res.data;
    }
    if (res.data.status === 302) {
      util.deleCookies();
      MessageBox.alert(res.data.msg || res.data.errMsg, '提示', {
        confirmButtonText: '确定',
        callback: () => {
          window.location.href = axios.baseURL.loginUrl;
        },
      });
    }
    // 全局统一出错处理
    if (!res.data.ok) {
      if (res.data.errMsg) {
        Message.error(res.data.errMsg || res.data.msg);
      }
      return res.data;
    }
    return res.data;
  },
  error =>
    Promise.reject(error.response),
);
export default axios;
