<template lang="pug">

</template>

<script>
export default {
  name: 'dailyTrendComponent',
};
</script>

<style scoped>

</style>
