<template lang="pug">

</template>

<script>
export default {
  name: 'metricComponent',
};
</script>

<style scoped>

</style>
