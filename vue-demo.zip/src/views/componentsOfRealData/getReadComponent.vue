<template lang="pug">

</template>

<script>
export default {
  name: 'getReadComponent',
};
</script>

<style scoped>

</style>
