<template lang="pug">

</template>

<script>
export default {
  name: 'getDataComponent',
};
</script>

<style scoped>

</style>
