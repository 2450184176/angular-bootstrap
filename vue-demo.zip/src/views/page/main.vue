<template>
    <div class="main">
        <codemirror
            ref="myCm"
            :value="code"
            :options="cmOptions"
            @ready="onCmReady"
            @input="onCmCodeChange">
        </codemirror>
        <br>
        <el-button type="success" size="small" @click="getSelection">获得选中的code</el-button>
    </div>
</template>

<script>
import 'static/css/codemirror.css';
import 'static/css/show-hint.css';
import 'codemirror/lib/codemirror';
import 'codemirror/mode/sql/sql';
import 'codemirror/addon/hint/show-hint';
import 'codemirror/addon/hint/sql-hint';
import 'codemirror/addon/hint/anyword-hint';
import 'codemirror/addon/display/placeholder';

export default {
  data() {
    return {
      code: 'select * from db.table limit 100;',
      cmOptions: {
        lineNumbers: true,
        indentUnit: 4,
        autofocus: true,
        styleActiveLine: true,
        matchBrackets: true,
        mode: 'text/x-mysql',
        lineWrapping: true,
        theme: 'default',
        extraKeys: {
          Ctrl: 'autocomplete',
        },
        foldGutter: true,
        placeholder: "Please end with ';'",
      },
    };
  },
  methods: {
    onCmReady(cm) {
      cm.on('keypress', () => {
        cm.showHint();
      });
    },
    onCmCodeChange(newCode) {
      this.code = newCode;
    },
    getSelection() {
      return this.codeMirror.getSelections().toString();
    },
  },
  computed: {
    codeMirror() {
      return this.$refs.myCm.codemirror;
    },
  },
};
</script>

<style scoped lang="scss">
    .main{
        margin-top: 20px;
    }
</style>
