<template>
    <div class="breadPath">
        <span>当前位置：</span><span>{{location}}</span>
    </div>
</template>

<script>
export default {
  name: 'headBread',
  data() {
    return {
      location: '',
    };
  },
  created() {
    this.setCurrentBread(this.$route.path);
  },
  methods: {
    setCurrentBread(e) {
      switch (e) {
        case '/realData':
          this.location = '实时数据';
          break;
        case '/myData':
          this.location = '我的数据';
          break;
        case '/newTopic':
          this.location = '新建Topic';
          break;
        case '/getData':
          this.location = '数据采集';
          break;
        default:
          this.location = '实时数据';
      }
    },
  },
  watch: {
    '$route.path': {
      handler(path) {
        this.setCurrentBread(path);
      },
    },
  },
};
</script>

