import Vue from 'vue';
import elementui from 'element-ui';
import echarts from 'echarts';
import HeadNav from '@/components/commonComponents/headNav';
import RviewSelect from '@/components/commonComponents/selectComponent';
import VueCodemirror from 'vue-codemirror';
import 'element-ui/lib/theme-chalk/index.css';
import 'static/font/iconfont/iconfont.css';
import axios from './services/http';
import Fetch from './services/dataHubAjax';
import store from './store';
import router from './router';
import App from './App';
import './lib';

Vue.use(elementui);
Vue.component('HeadNav', HeadNav);
Vue.component('RviewSelect', RviewSelect);
Vue.use(VueCodemirror, { events: ['ready', 'input', 'getSelection'] });
Vue.config.productionTip = false;
Vue.prototype.$axios = axios;
Vue.prototype.$Fetch = Fetch;
Vue.prototype.$echarts = echarts;
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App),
});
