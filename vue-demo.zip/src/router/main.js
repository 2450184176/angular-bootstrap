const MainLayOut = () => import('@/views/layout');
const main = () => import('@/views/page/main');
const realData = () => import('@/views/page/realData');
const myData = () => import('@/views/page/myData');
const newTopic = () => import('@/views/page/newTopic');
const getData = () => import('@/views/page/getData');
export default [
  {
    path: '/',
    component: MainLayOut,
    children: [
      // { path: '/', component: Main, meta: { title: '总览' } },
      { path: '/', component: realData, meta: { title: '实时数据' } },
      { path: '/myData', component: myData, meta: { title: '我的数据' } },
      { path: '/newTopic', component: newTopic, meta: { title: '新建TOPIC' } },
      { path: '/getData', component: getData, meta: { title: '数据采集' } },
      { path: '/main', component: main, meta: { title: 'main' } },
    ],
  },
];
