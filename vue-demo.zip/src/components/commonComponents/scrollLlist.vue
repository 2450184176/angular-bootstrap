<template lang="pug">
    <div class="rview-scroll-list-wrap">
        <div :style="listStyle" ref="rview-scroll-list" class="rview-scroll-list">
            <ul ref="rview-scroll-list-items" :style="itemsStyle" class="rview-scroll-list-items">
                <li v-for="(item,index) in dataList" ref="rview-scroll-list-item" @click="$emit('change',item)" :class="activeValue == item.value ? 'is-active' :''" class="rview-scroll-list-item">
                    <div v-if="item.html" v-html="item.html" class="rview-scroll-list-content"></div>
                    <div v-else="v-else" class="rview-scroll-list-content">{{item.label}}</div>
                </li>
                <li v-if="!dataList.length" class="rview-scroll-list-nodata">暂无数据</li>
            </ul>
        </div>
        <div v-if="pageShow" class="rview-scroll-list-page-road">
            <div class="rview-scroll-list-page"><span class="desc">共 {{Math.floor(list.length/size)}} 页 {{list.length}} 条</span><span>第</span>
                <div class="page-input">
                    <input v-model="page" type="number" min="1" :max="Math.floor(list.length/size)" @input="fixPageInput"/>
                </div><span>页</span>
            </div>
        </div>
    </div>
</template>
<script>
/* eslint-disable no-unused-vars */
/* eslint-disable no-lonely-if */
/* eslint-disable eqeqeq */
export default {
  props: {
    list: {
      type: Array,
      default() {
        return [];
      },
    },
    size: {
      type: Number,
      default() {
        return 10;
      },
    },
    activeValue: {
      type: null,
      default() {
        return '';
      },
    },
  },
  data() {
    return {
      page: 1,
      listStyle: {},
      pageShow: false,
      itemsStyle: {},
      top: 0,
      listLen: 0,
      speed: 20,
    };
  },
  watch: {
    top(top) {
      this.itemsStyle = {
        top: `${top}px`,
      };
      if (top >= 0 && this.page === 1) {
        console.log('it is the top');
        this.$emit('attach-top');
      } else if (top <= this.$refs['rview-scroll-list'].offsetHeight - this.$refs['rview-scroll-list-items'].offsetHeight) {
        console.log('it is the bottom');
        this.$emit('attach-bottom');
      }
    },
    page(val) {
      this.getDataList(Number(val) || 1);
    },
    list(val) {
      this.listLen = val.length;
      this.top = 0;
      if (this.page == 1) {
        this.getDataList(Number(val) || 1);
      } else this.page = 1;
    },
    activeValue() {
      this.handlerActiveValue();
    },
  },
  computed: {


  },
  created() {
    this.listLen = this.list.length;
    this.getDataList(Number(this.page));
  },
  mounted() {
    this.setListHeight();
    this.handlerActiveValue();
    this.$nextTick(() => {
      this.setEvents();
    });
  },
  methods: {
    handlerActiveValue() {
      if (this.activeValue) {
        const index = this.list.findIndex(item => item.value == this.activeValue);
        if (index >= 0) {
          this.page = Math.ceil((index + 1) / this.size);
          this.$nextTick(() => {
            const maxLen = this.dataList.length - 1;
            const minTop = -(this.$refs['rview-scroll-list-items'].offsetHeight - this.$refs['rview-scroll-list'].offsetHeight);
            const currentTop = -(this.$refs['rview-scroll-list-item'][index % this.size].offsetTop);
            this.top = Math.max(minTop, currentTop);
          });
        }
      }
    },
    getDataList(page) {
      if (page === 1) {
        const len = Math.min(this.size * 2, this.listLen);
        this.dataList = this.list.slice(0, len);
      }
      const len = Math.min((page + 1) * this.size, this.listLen);
      this.dataList = this.list.slice((page - 1) * this.size, len);
    },
    fixPageInput() {
      const maxPage = Math.floor(this.listLen / this.size);
      if (this.page > maxPage) this.page = maxPage;
      else if (this.page < 1) this.page = 1;
    },
    setEvents() {
      const $vm = this;
      const listNode = this.$refs['rview-scroll-list'];
      const ulNode = this.$refs['rview-scroll-list-items'];
      function stopBodyWheel(event) {
        if (event.path.some(node => node.className === 'rview-scroll-list-items')) return false;
        return true;
      }
      if (!document.body.onmousewheel || document.body.onmousewheel.name !== 'stopBodyWheel') {
        document.body.onmousewheel = stopBodyWheel;
      }
      this.addMouseWheelEvent(listNode, (event) => {
        let wheelDir = true;
        //   向下为true,向上为false;
        if (event.wheelDelta) wheelDir = event.wheelDelta < 0;
        else if (event.detail) wheelDir = event.detail > 0;
        $vm.top = parseInt(ulNode.style.top || 0, 10);
        const boundaryItem = $vm.getBoundaryItem();
        if (wheelDir) {
          // 当ul 向上移动范围使得界限节点越过listNode的顶端，那么数据将更新
          if (Math.abs($vm.top) >= boundaryItem.offsetTop + boundaryItem.offsetHeight) {
            if ($vm.dataList.length === $vm.size * 2) {
              $vm.page = Number($vm.page) + 1;
              $vm.top = 0;
            } else if (Math.abs($vm.top) + listNode.offsetHeight < ulNode.offsetHeight) {
              $vm.top -= $vm.speed;
            }
          } else if (Math.abs($vm.top) + listNode.offsetHeight < ulNode.offsetHeight) {
            $vm.top -= $vm.speed;
          }
        } else {
          // 当ul向下移动时当第一个节点顶部到达listNode的顶端时(ul的top >= 0时)，数据需要更新
          if ($vm.top >= 0) {
            if ($vm.page > 1) {
              $vm.page = Number($vm.page) - 1;
              $vm.$nextTick(() => {
                const boundaryItem2 = $vm.getBoundaryItem();
                $vm.top = -boundaryItem.offsetTop - boundaryItem2.offsetHeight;
              });
            } else if ($vm.top < 0) {
              $vm.top += $vm.speed;
            } else {
              $vm.top = 0;
            }
          } else {
            $vm.top += $vm.speed;
          }
        }
      });
    },
    setListHeight() {
      const listHeight = this.$refs['rview-scroll-list'].offsetHeight;
      const itemsHeight = this.$refs['rview-scroll-list-items'].offsetHeight;
      if (!this.dataList.length) {
        this.$refs['rview-scroll-list'].style.height = '50px';
      } else if (listHeight > itemsHeight) {
        this.$refs['rview-scroll-list'].style.height = `${itemsHeight}px`;
      } else {
        this.pageShow = true;
      }
    },
    addMouseWheelEvent(element, func) {
      if (typeof element.onmousewheel === 'object') {
        this.addEvent(element, 'mousewheel', func);
      }

      if (typeof element.onmousewheel === 'undefined') {
        this.addEvent(element, 'DOMMouseScroll', func, false);
      }
    },
    removeMouseWheelEvent(element, func) {
      if (typeof element.onmousewheel === 'object') {
        this.removeEvent(element, 'mousewheel', func);
      }

      if (typeof element.onmousewheel === 'undefined') {
        this.removeEvent(element, 'DOMMouseScroll', func, false);
      }
    },
    addEvent(element, type, func, flag) {
      if (element.addEventListener) element.addEventListener(type, func, Boolean(flag));
      else element.attachEvent(`on${type}`, func);
    },
    removeEvent(element, type, func, flag) {
      if (element.removeEventListener) element.removeEventListener(type, func, Boolean(flag));
      else element.detachEvent(`on${type}`, func);
    },
    getBoundaryItem() {
      const index = Math.min(this.size - 1, this.dataList.length - 1);
      return this.$refs['rview-scroll-list-item'][index];
    },
  },
};
</script>
<style lang="scss" scoped>
.rview-scroll-list-wrap{
    background: #ffffff;
   & * {
      padding: 0;
      margin: 0;
      box-sizing: border-box;
    }
    left: 0;
    top: 0;
    width: 100%;
    border: 1px solid #cccccc;
    border-radius: 4px;
    padding: 10px 0;
    box-sizing: border-box;
    position: absolute;
  .rview-scroll-list{
    position: relative;
    height: 230px;
    width: 100%;
    overflow: hidden;
    ul,li{
      list-style: none;
    }
    .rview-scroll-list-items{
      position: absolute;
      left: 0;
      top: 0;
      width: 100%;
      .rview-scroll-list-nodata{
        padding: 5px 10px;
        line-height: 1.5;
        text-align: center;
      }
      .rview-scroll-list-item{
        padding: 5px 20px 5px 10px;
        line-height: 1.5;
        cursor: pointer;
        &.is-active{
          background: #33aaff;
          color: #ffffff;
          transition: all 0.2s ease;
          &:hover{
             background: #33aaff;
          }
        }
        &:hover{
          background: #eeeeee;
        }
      }
    }
  }
  &:hover .rview-scroll-list-page-road{
    opacity: 0.8;
    transition: opacity 0.5s ease;
  }
  .rview-scroll-list-page-road{
    width: 14px;
    background: #666666;
    height: 100%;
    position: absolute;
    right: 2px;
    top:0;
    border-radius: 7px;
    color: #ffffff;
    justify-content: center;
    align-items: center;
    display: flex;
    opacity: 0;
    .rview-scroll-list-page{
      // transform: scale(0.9);
      font-size: 10px;
      display: flex;
      justify-content: center;
      align-items: center;
      writing-mode: tb-rl;
      .desc{
        margin-bottom: 10px;
      }
      .page-input{
        width: 12px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 10px 0;
        input{
          width: 40px;
          height: 12px;
          transform: rotate(90deg);
          border: 0;
          padding: 0 5px;
        }
      }
    }
  }
}
</style>
