/* eslint-disable no-param-reassign */
/* eslint-disable no-shadow */
/* eslint-disable no-console */
import { MessageBox } from 'element-ui';
import axios from '../../services/http';
import util from '../../lib/util';

const state = {
  userInfo: JSON.parse(localStorage.getItem('datahub_userInfo') || '{}'),
  navInfo: JSON.parse(localStorage.getItem('datahub_navInfo') || '{}'),
  breadPath: '实时数据',
};

const mutations = {
  setUserInfo(state, userInfo) {
    state.userInfo = userInfo;
    localStorage.setItem('datahub_userInfo', JSON.stringify(state.userInfo));
  },
  clearUserInfo(state) {
    state.userInfo = {};
    state.navInfo = {};
    mutations.setUserInfo(state, {});
    mutations.setNavInfo(state, {});
  },
  setNavInfo(state, navInfo) {
    if (navInfo) state.navInfo = Object.assign(state.navInfo, navInfo);
    localStorage.setItem('datahub_navInfo', JSON.stringify(state.navInfo));
  },
  setBreadPath(state, pathParams) {
    if (pathParams) state.breadPath = pathParams;
  },
};

const actions = {
  userLogOut(state) {
    MessageBox.confirm('你确定退出登录么？', '提示', {
      type: 'warning',
    }).then(() => {
      util.deleCookies();
      state.commit('clearUserInfo');
      window.location.href = '/portal-web-system/usermanage/admin/loginOut';
    }).catch(() => {});
  },
  async getUserInfo(state) {
    const ret = await axios.post(`${axios.baseURL.systemUrl}/usermanage/admin/getUser`);
    if (ret.ok) {
      state.commit('setUserInfo', ret.data || {});
      state.commit('setNavInfo', { userName: ret.data.name });
    } else {
      state.commit('clearUserInfo');
      util.deleCookies();
      MessageBox.alert(ret.data.msg || ret.data.errMsg || '请重新登录', '提示', {
        confirmButtonText: '确定',
        callback: () => {
          window.location.href = axios.baseURL.loginUrl;
        },
      });
    }
  },
  async getNoticeNum(state) {
    const res = await axios.get(`${axios.baseURL.mcCtrl}/message/unreadCount`);
    if (res.ok) state.commit('setNavInfo', { noticeNum: res.data });
  },
};

const getters = {
  navInfo(state) {
    return Object.assign(state.navInfo, { helpDocUrl: 'http://10.117.176.210:8181/docs/dataIDE/49' });
  },
  userName(state) {
    return state.userInfo.name;
  },
  userId(state) {
    return state.userInfo.id;
  },
  userInfo(state) {
    return state.userInfo;
  },
  getBreadPath(state) {
    localStorage.setItem('dataHub_breadPath', state.breadPath);
    return state.breadPath;
  },
};
export default {
  // namespaced: true 激活命名空间
  state,
  mutations,
  actions,
  getters,
};
