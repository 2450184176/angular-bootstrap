<template lang="pug">
    el-container#app
        el-header(height='65px')
            head-nav(:menus='navItems', :nav-info='navInfo', @logout="$store.dispatch('userLogOut')")
                .log(slot='logo')
                    img(src='static/img/sflogo.png')
                    a.log-text(href='#/') 实时数据
        headBread
        el-main
            router-view
        footerCopyright
</template>

<script>
import { mapActions, mapGetters } from 'vuex';
import headBread from '@/views/commonComponents/headBread';
import footerCopyright from '@/views/commonComponents/footer-copyRight';

export default {
  name: 'app',
  data() {
    return {
      navItems: [
        // { label: '总览', path: '/' },
        { label: '实时数据', path: '/' },
        { label: '我的数据', path: '/myData' },
        { label: '新建TOPIC', path: '/newTopic' },
        { label: '数据采集', path: '/getData' },
      ],
    };
  },
  components: {
    headBread,
    footerCopyright,
  },
  computed: {
    ...mapGetters([
      'navInfo',
    ]),
  },
  methods: {
    ...mapActions([
      'getUserInfo',
      'getNoticeNum',
    ]),
  },
  created() {
    this.getUserInfo();
    this.getNoticeNum();
  },
};
</script>

<style lang="scss">
  html,body,#app{
    width: 100%;
    height: 100%;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #666666;
    font-size: 12px;
    font-family: Microsoft YaHei;
    background: #EEF4F9;
  }
  .el-header{
    padding: 0;
  }
  .el-main{
    width: 100%;
    padding: 0 20px 0 20px;
  }
</style>
