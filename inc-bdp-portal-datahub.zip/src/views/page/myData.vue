<template>
    <div>
        <div class="searchDiv">
            <div class="outerFlex">
                <div>主题名称：</div>
                <div>
                    <el-input size="small" v-model="formInfo.topicName" placeholder="请输入主题名称"></el-input>
                </div>
            </div>
            <div class="outerFlex">
                <div>应用名称：</div>
                <div>
                    <el-input size="small" v-model="formInfo.appName" placeholder="请输入应用名称"></el-input>
                </div>
            </div>
            <div class="outerFlex">
                <div>业务系统：</div>
                <div>
                    <el-input size="small" v-model="formInfo.sysName" placeholder="请输入业务系统"></el-input>
                </div>
            </div>
            <div class="outerFlex">
                <div>状态：</div>
                <div>
                    <el-select size="small" v-model="formInfo.value" placeholder="请选择状态">
                        <el-option
                            v-for="item in formInfo.status"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                        </el-option>
                    </el-select>
                </div>
            </div>
            <div class="btn">
                <el-button size="small" type="primary" @click="onSubmit()">查  询</el-button>
            </div>
        </div>
        <div class="tableOfSelected">
            <div class="forChoose">
                <span @click="myData" :style="[this.isCheck ? active : '']">我的数据</span>
                <span @click="mySub" :style="[!this.isCheck ? active : '']">我的订阅</span>
            </div>
            <div class="line"></div>
            <div class="bottomLine" :style="[!this.isCheck ? bottomLine : '']"></div>
            <div class="tableData">
                <el-table
                    :data="tableData"
                    style="width: 100%;font-size: 12px;"
                    element-loading-text="拼命加载中"
                    v-loading="listLoad">
                    <el-table-column
                        label="ID"
                        prop="id">
                    </el-table-column>
                    <el-table-column
                        label="主题名称"
                        prop="topicName">
                    </el-table-column>
                    <el-table-column
                        label="类型"
                        prop="type">
                    </el-table-column>
                    <el-table-column
                        label="应用名称"
                        prop="appName">
                    </el-table-column>
                    <el-table-column
                        label="业务系统"
                        prop="sysName">
                    </el-table-column>
                    <el-table-column
                        label="应用名称"
                        prop="appName">
                    </el-table-column>
                    <el-table-column
                        label="状态"
                        prop="status">
                        <template scope="scope">
                            <el-tag size="medium" v-if="scope.row.status==='0'">无效</el-tag>
                            <el-tag size="medium" v-else-if="scope.row.status==='1'" type="success">有效</el-tag>
                            <el-tag size="medium" v-else-if="scope.row.status==='2'" type="warning">审核中</el-tag>
                            <el-tag size="medium" v-else-if="scope.row.status==='3'" type="danger">驳回</el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column
                        label="最新数据时间"
                        :formatter="dataFormat"
                        prop="time">
                    </el-table-column>
                    <el-table-column label="操作">
                        <template slot-scope="scope">
                            <el-button
                                size="small"
                                @click="handleEdit(scope.$index, scope.row)">查看</el-button>
                            <el-button
                                size="small"
                                type="danger"
                                @click="handleDelete(scope.$index, scope.row)">订阅</el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="pageNumber">
                    <el-pagination
                        @size-change="sizeChange"
                        @current-change="pageChange"
                        :current-page="pageNum"
                        :page-sizes="[100, 200, 300, 400]"
                        :page-size="100"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="totalCounts">
                    </el-pagination>
                </div>
            </div>
        </div>
    </div>
</template>
<script>

export default {
  name: 'myData',
  data() {
    return {
      formInfo: {
        topicName: '',
        appName: '',
        sysName: '',
        status: [{
          value: '选项1',
          label: '有效',
        }, {
          value: '选项2',
          label: '无效',
        }, {
          value: '选项3',
          label: '驳回',
        }, {
          value: '选项4',
          label: '审核中',
        }],
        value: '',
      },
      listData: [],
      totalCounts: 400,
      pageNum: 1,
      listLoad: true,
      isCheck: true,
      active: { color: '#20a0ff' },
      bottomLine: { left: '108px', transition: 'all 0.1s ease-in 0.1s' },
      tableData: [],
    };
  },
  methods: {
    dataFormat(row, column) {
      const date = row[column.property];
      if (date === null) {
        return '-';
      }
      return this.$moment(date).format('YYYY-MM-DD HH:mm:ss');
    },
    handleEdit(index, row) {
      console.log(index, row);
    },
    handleDelete(index, row) {
      console.log(index, row);
    },
    sizeChange(val) {
      console.log(`每页 ${val} 条`);
    },
    pageChange(val) {
      console.log(`当前页: ${val}`);
    },
    onSubmit() {
      console.log('submit!');
    },
    myData() {
      this.listLoad = true;
      console.info('我的数据');
      this.isCheck = true;
      this.loadData();
    },
    mySub() {
      this.listLoad = true;
      console.info('我的订阅');
      this.isCheck = false;
      this.loadSubData();
    },
    async loadData() {
      const res = await this.$Fetch.getOriginDataList();
      this.tableData = res.data;
      this.listLoad = res.load;
    },
    async loadSubData() {
      const res = await this.$Fetch.getSubData();
      this.tableData = res.data;
      this.listLoad = res.load;
    },
  },
  mounted() {
  },
  created() {
    this.loadData();
  },
};
</script>
