<template>
    <div class="cardMain">
        <div class="cardRow">
            <div class="divCard">
                <div class="title">
                    文件上传
                </div>
                <div class="desc">
                    支持本地文件上传到topic，主要用在测试场景，最大支持1MB的CSV文件。
                </div>
            </div>
            <div class="divCard">
                <div class="title">
                    MQTT
                </div>
                <div class="desc">
                    支持MQTT类型的TOPIC数据采集上传，方法见明细。
                </div>
            </div>
            <div class="divCard">
                <div class="title">
                    HTTP
                </div>
                <div class="desc">
                    支持HTTP类型的TOPIC数据采集上传，方法见明细。
                </div>
            </div>
            <div class="divCard">
                <div class="title">
                    TCP
                </div>
                <div class="desc">
                    支持TCP类型的TOPIC数据采集上传，方法见明细。
                </div>
            </div>
        </div>
        <div class="cardRow">
            <div class="divCard">
                <div class="title">
                    BEE
                </div>
                <div class="desc">
                    支持bee log类型的TOPIC数据采集上传，方法见明细。
                </div>
            </div>
            <div class="divCard">
                <div class="title">
                    LogFile
                </div>
                <div class="desc">
                    支持log file类型的TOPIC数据采集上传，方法见明细。
                </div>
            </div>
            <div class="divCard">
                <div class="title">
                    xxxx
                </div>
                <div class="desc">
                    支持本地文件上传到topic，主要用在测试场景，最大支持1MB的CSV文件。
                </div>
            </div>
            <div class="divCard">
                <div class="title">
                    yyyy
                </div>
                <div class="desc">
                    支持本地文件上传到topic，主要用在测试场景，最大支持1MB的CSV文件。
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
  name: 'getData',
  data() {
    return {
    };
  },
  methods: {
  },
  mounted() {
  },
  created() {
  },
};
</script>
