<template>
    <div>
        <div class="formData">
            <div class="titleCss">基本信息</div>
            <div class="lineCss"></div>
            <div class="bottomLineCss"></div>
            <div class="formInfo">
                <div class="outerBox">
                    <div>主题名称：</div>
                    <div>
                        <el-input
                            size="small"
                            autosize
                            clearable
                            placeholder="请输入主题名称"
                            v-model="formInfo.topicName">
                        </el-input>
                    </div>
                </div>
                <div class="outerBox">
                    <div>主题类型：</div>
                    <div>
                        <el-select size="small" v-model="formInfo.type" placeholder="请选择">
                            <el-option
                                v-for="item in formInfo.typeOptions"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </div>
                </div>
                <div class="outerBox">
                    <div>生命周期：</div>
                    <div>
                        <el-select size="small" v-model="formInfo.life" placeholder="请选择">
                            <el-option
                                v-for="item in formInfo.lifeOptions"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </div>
                </div>
                <div class="outerBox">
                    <div>所属应用：</div>
                    <div>
                        <el-select size="small" v-model="formInfo.app" placeholder="请选择">
                            <el-option
                                v-for="item in formInfo.appOptions"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </div>
                </div>
            </div>
            <div class="formInfo">
                <div class="outerBox">
                    <div>负责人：</div>
                    <div>
                        <el-input
                            size="small"
                            autosize
                            clearable
                            placeholder="请输入负责人"
                            v-model="formInfo.peopleName">
                        </el-input>
                    </div>
                </div>
                <div class="outerBox">
                    <div>所属部门：</div>
                    <div>
                        <el-select size="small" v-model="formInfo.dept" placeholder="请选择">
                            <el-option
                                v-for="item in formInfo.deptOptions"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </div>
                </div>
                <div class="outerBox">
                    <div>说明：</div>
                    <div>
                        <el-input
                            maxlength='50'
                            resize="horizontal"
                            type="textarea"
                            placeholder="请输入内容"
                            v-model="formInfo.desc">
                        </el-input>
                    </div>
                </div>
            </div>
            <br>
            <div class="titleCss">架构信息</div>
            <div class="lineCss"></div>
            <div class="bottomLineCss"></div>
            <div class="tableData">
                <el-table
                    :data="formInfo.tableData"
                    style="width: 100%">
                    <el-table-column
                        label="序号"
                        type="index"
                        width="50">
                    </el-table-column>
                    <el-table-column
                        prop="column"
                        label="字段名">
                        <template slot-scope="scope">
                            <el-input
                                size="small"
                                autosize
                                clearable
                                placeholder="请输入字段名"
                                v-model="scope.row.column">
                            </el-input>
                        </template>
                    </el-table-column>
                    <el-table-column
                        prop="type"
                        label="类型">
                        <template slot-scope="scope">
                            <el-input
                                v-show="scope.row.type!==''"
                                size="small"
                                autosize
                                clearable
                                v-model="scope.row.type">
                            </el-input>
                            <el-autocomplete
                                size="small"
                                v-show="scope.row.type===''"
                                class="inline-input"
                                v-model="scope.row.type"
                                :fetch-suggestions="querySearch"
                                placeholder="请选择类型">
                            </el-autocomplete>
                        </template>
                    </el-table-column>
                    <el-table-column
                        prop="comment"
                        label="注释">
                        <template slot-scope="scope">
                            <el-input
                                size="small"
                                autosize
                                clearable
                                placeholder="请输入注释"
                                v-model="scope.row.comment">
                            </el-input>
                        </template>
                    </el-table-column>
                    <el-table-column
                        prop="address"
                        fixed="right"
                        label="操作"
                        width="100">
                        <template slot-scope="scope">
                            <el-button
                                size="small"
                                type="danger"
                                @click="handleDelete(scope.$index)">删除</el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="addBtn">
                    <el-button size="small" type="info" icon="el-icon-plus" circle @click="addStructure"></el-button>
                </div>
            </div>
            <div class="bottomBtn">
                <el-button size="small">重置</el-button>
                <el-button size="small" type="primary">提交</el-button>
            </div>
        </div>
    </div>
</template>

<script>

export default {
  name: 'newTopic',
  data() {
    return {
      formInfo: {
        topicName: '',
        peopleName: '',
        typeOptions: [{
          value: '选项1',
          label: '黄金糕',
        }, {
          value: '选项2',
          label: '双皮奶',
        }, {
          value: '选项5',
          label: '北京烤鸭',
        }],
        lifeOptions: [{
          value: '选项1',
          label: '黄金糕',
        }, {
          value: '选项2',
          label: '双皮奶',
        }, {
          value: '选项5',
          label: '北京烤鸭',
        }],
        appOptions: [{
          value: '选项1',
          label: '黄金糕',
        }, {
          value: '选项2',
          label: '双皮奶',
        }, {
          value: '选项5',
          label: '北京烤鸭',
        }],
        deptOptions: [{
          value: '选项1',
          label: '黄金糕',
        }, {
          value: '选项2',
          label: '双皮奶',
        }, {
          value: '选项5',
          label: '北京烤鸭',
        }],
        type: '',
        life: '',
        app: '',
        dept: '',
        desc: '',
        tableData: [{
          column: 'user_name',
          type: 'varchar',
          comment: '用户名称',
        }, {
          column: 'user_phone',
          type: 'int',
          comment: '用户电话号码',
        }, {
          column: 'user_address',
          type: 'varchar',
          comment: '用户住址',
        }, {
          column: 'user_job',
          type: 'varchar',
          comment: '用户工作',
        }],
      },
      restaurants: [{
        value: 'int',
      }, {
        value: 'float',
      }, {
        value: 'date',
      }, {
        value: 'Boolean',
      }, {
        value: 'time',
      }, {
        value: 'timestamp',
      }, {
        value: 'bigint',
      }, {
        value: 'double',
      }, {
        value: 'char',
      }, {
        value: 'varchar',
      }],
    };
  },
  methods: {
    createStructure(column, type, comment) {
      return {
        column: column || '',
        type: type || '',
        comment: comment || '',
      };
    },
    addStructure() {
      const oneStructure = this.createStructure();
      this.formInfo.tableData.push(oneStructure);
    },
    handleDelete(index) {
      this.formInfo.tableData.splice(index, 1);
    },
    querySearch(queryString, cb) {
      const restaurants = this.restaurants;
      const results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants;
      cb(results);
    },
    createFilter(queryString) {
      return (restaurant) => {
        return (restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0);
      };
    },
  },
  mounted() {
  },
  created() {
  },
};
</script>
