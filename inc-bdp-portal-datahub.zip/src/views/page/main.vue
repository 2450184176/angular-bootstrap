<template>
    <div class="main">
        <el-button-group>
            <el-button type="primary" icon="el-icon-edit" size="small"></el-button>
            <el-button type="primary" icon="el-icon-share" size="small"></el-button>
            <el-button type="primary" icon="el-icon-delete" size="small"></el-button>
            <el-dropdown size="small">
                <el-button type="primary" size="small">
                    更多菜单<i class="el-icon-arrow-down el-icon--right"></i>
                </el-button>
                <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item>黄金糕</el-dropdown-item>
                    <el-dropdown-item>狮子头</el-dropdown-item>
                    <el-dropdown-item>螺蛳粉</el-dropdown-item>
                    <el-dropdown-item>双皮奶</el-dropdown-item>
                    <el-dropdown-item>蚵仔煎</el-dropdown-item>
                </el-dropdown-menu>
            </el-dropdown>
        </el-button-group>
    </div>
</template>
