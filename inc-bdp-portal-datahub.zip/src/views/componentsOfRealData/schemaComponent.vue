<template lang="pug">

</template>

<script>
export default {
  name: 'schemaComponent',
};
</script>

<style scoped>

</style>
