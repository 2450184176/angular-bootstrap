<template lang="pug">
    <div class="pathStyle">
        <span>版权所有copyright@顺丰科技大数据平台部 2016-2030</span>
    </div>
</template>

<script>
export default {
  name: 'footer-copyRight',
};
</script>

