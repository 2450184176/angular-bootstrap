<template lang="pug">
  .rview-scroll-list-select
    .rview-scroll-list-input(:class="showList ? 'list-is-show' : ''",ref="rview-scroll-list-input")
        .rview-scroll-list-mulitiple-input(v-if="mulitiple")
            span.closeable(v-for="(item,index) in value") {{item.label}}
                i.close-btn(@click="removeItme(index)")
            input(v-model="rvalue",:placeholder="placeholder || '请选择'",type="text",:disabeld="disabled",@keyup.stop="getKeyEvent",@focus="onFocus",@blur="isFocus = false")
        input.rview-scroll-list-inner(v-else,v-model="rvalue",:placeholder="placeholder || '请选择'",type="text",:disabeld="disabled",@keyup.stop="getKeyEvent",@focus="onFocus",@blur="isFocus = false")
        .rview-scroll-list-direct
    .rview-scroll-list-options(:style="listStyle",ref="rview-scroll-list-options",v-show="showList",@mouseenter="overList = true",@mouseleave="overList = false")
        rview-scroll-list(:list="filteOptions",ref="rview-scroll-list",:size="listSize",:active-value="activeValue",@change="getOption")
</template>
<script>
/*
  name:rview-scroll-list-select.
  effect:It can be used to loading large number datas of list.You can use it for single select,and also can do the mulitiple select.
  效果：便于大量数据的列表。可以单选，可以多选。
  props:
    disabled:Boolean,default false.If you change the value as true,then the input will be disabled.
    disabled:布尔值，默认false。如果你选择true,那么输入框将不可输入。
    value:You cna use 'v-model' bind the value.It can be string\number\array.If you set mulitiple,you should better use 'v-model' bind an array.
    value:你可以使用‘v-model’绑定value值。可以是string/number/array类型。如果你使用多重选择，你最好绑定一个数组。
    options:This is all the datas you want to choose.
    options:传入你的所有备选项。
    listSize:It is the number of lists to be rendered at a time,default 20.
    listSize:列表一次渲染的数量。默认值20.
    filteable:Do you want to filter the datas.
    filteable:是否需要过滤。
    filter:If you want to filter the datas,you can custom your filter function.But it is not needed.We have default filter function.
    filter:如果你需要过滤，可以自定义你的过滤函数。
    remoteFilter:An asynchronous filter function which you are customed.
    remoteFilter:这里是异步的过滤函数。可以做输入数据后的远程请求。
    mulitiple:Boolean,default false.If you change the value as true,then you can do the mulitiple select.
    mulitiple:布尔值。默认false.如果你改为true.你可以做多重选择。
  attentions:
    options:It must be an Array,and the element must be an Object,and the format just like {label:'',value:'',data:'',html:''}.the 'value' is needed.
    If you want to custom the list style.you can fill the attribute 'html'.or you must fill 'label'.
    options:必须使用array类型。而且每个元素都是Object，格式是{label:'',value:'',data:'',html:''}。‘value’是必须的。如果你要自定义样式，
    你可以使用‘html’属性。否则必须填写‘label’.
*/
import RviewScrollList from './scrollLlist';
/* eslint-disable no-unused-vars */
/* eslint-disable no-lonely-if */
/* eslint-disable eqeqeq */
export default {
  components: {
    RviewScrollList,
  },
  props: {
    placeholder: String,
    disabled: {
      type: Boolean,
      default() {
        return false;
      },
    },
    value: [String, Number, Array],
    options: {
      type: Array,
      default() {
        return [];
      },
    },
    listSize: {
      type: Number,
      default() {
        return 10;
      },
    },
    filteable: {
      type: Boolean,
      default() {
        return false;
      },
    },
    filter: Function,
    remoteFilter: Function,
    mulitiple: Boolean,
  },
  data() {
    return {
      rvalue: '',
      activeValue: '',
      isFocus: false,
      overList: false,
      index: -1,
      filteOptions: [],
      listStyle: {},
    };
  },
  computed: {
    showList() {
      return this.isFocus || this.overList;
    },
  },
  watch: {
    value() {
      this.recoverRvalue();
    },
    index(index) {
      if (index >= 0) this.activeValue = this.filteOptions[this.index].value;
      else this.activeValue = '';
    },
    showList(va) {
      this.recoverRvalue();
      if (va) {
        this.$nextTick(() => {
          const inputNode = this.$refs['rview-scroll-list-input'];
          const offset = this.getFixedPosition(inputNode);
          const top = offset.top + inputNode.offsetHeight + 10;
          const optionsHeight = this.$refs['rview-scroll-list'].$el.offsetHeight;
          this.listStyle = {
            position: 'fixed',
            width: `${inputNode.offsetWidth}px`,
            left: `${offset.left}px`,
            top: `${top + optionsHeight > document.body.offsetHeight ? offset.top - optionsHeight - 10 : top}px`,
          };
        });
      }
    },
    filteOptions() {
      this.index = 0;
    },
  },

  created() {
    this.filteOptions = this.options;
    if (this.value) {
      this.recoverRvalue();
    }
    this.$watch('rvalue', async () => {
      if (this.filteable) this.filteOptions = await this.filteMethod();
    });
  },
  methods: {
    onFocus() {
      this.isFocus = true;
    },
    removeItme(index) {
      this.value.splice(index, 1);
      this.$emit('input', this.value);
    },
    recoverRvalue() {
      this.filteOptions = this.options;
      this.index = this.filteOptions.findIndex(item => item.value === this.value);
      if (this.index >= 0) this.rvalue = this.filteOptions[this.index].label;
      else this.rvalue = '';
    },
    getOption(item) {
      if (this.mulitiple) {
        if (this.value.findIndex(val => val.value == item.value) !== -1) return;
        this.value.push(item);
        this.$emit('input', this.value);
      } else {
        this.rvalue = item.label;
        this.$emit('input', item.value);
      }
      this.$emit('change', item);
    },
    async filteMethod() {
      let options = [];
      if (this.remoteFilter) options = await this.remoteFilter(this.rvalue, this.options);
      else if (this.filter) options = this.filter(this.rvalue, this.options);
      else options = this.options.filter(item => item.label.indexOf(this.rvalue) !== -1);
      return options;
    },
    getKeyEvent(event) {
      const e = event || window.event;
      switch (e.keyCode) {
        case 40:// 向下
          this.index = Math.min(this.index + 1, this.filteOptions.length - 1);
          break;
        case 38:// 向上
          this.index = Math.max(this.index - 1, 0);
          break;
        case 13:// 回车
          if (this.index >= 0) this.getOption(this.filteOptions[this.index]);
          break;
        default:
          break;
      }
    },
    // 获取元素与浏览器左边和顶部的距离
    getFixedPosition(node) {
      const offset = this.getFixedOffset(node);
      const scroll = this.getFixedTotalScroll(node);
      return {
        left: offset.left - scroll.left,
        top: offset.top - scroll.top,
      };
    },
    getComputedStyleValue(node, style) {
      let value = '';
      if (node.currentStyle) {
        value = node.currentStyle[style];
      } else {
        value = window.getComputedStyle(node)[style]; // 支持高级浏览器
      }
      return value;
    },
    // 获取元素到html左边和顶部的距离
    getFixedOffset(node) {
      const position = this.getComputedStyleValue(node, 'position');
      const offset = {
        left: node.offsetLeft,
        top: node.offsetTop,
      };
      if (position !== 'fixed' && node.offsetParent && node.offsetParent.nodeName !== 'HTML') {
        const parentOffset = this.getFixedOffset(node.offsetParent);
        offset.left += parentOffset.left;
        offset.top += parentOffset.top;
      }

      return offset;
    },
    // 获取元素到html之间所有的滚动距离
    getFixedTotalScroll(n) {
      const node = n.parentNode;
      let scroll = {
        left: node.scrollLeft,
        top: node.scrollTop,
      };
      if (node.parentNode.nodeName === 'BODY') {
        if (document.body && document.body.scrollTop && document.body.scrollLeft) {
          scroll = {
            top: document.body.scrollTop,
            left: document.body.scrollleft,
          };
        }
        if (document.documentElement && document.documentElement.scrollTop && document.documentElement.scrollLeft) {
          scroll = {
            top: document.documentElement.scrollTop,
            left: document.documentElement.scrollleft,
          };
        }
      }
      const position = this.getComputedStyleValue(node, 'position');
      if (node.nodeName !== 'HTML' && position !== 'fixed') {
        const parentScroll = this.getFixedTotalScroll(node);
        scroll.left += parentScroll.left;
        scroll.top += parentScroll.top;
      }
      return scroll;
    },
  },
};
</script>
<style lang="scss" scoped>
    .rview-scroll-list-select{
        height: 36px;
        position: relative;
        display: inline-block;
        &,& * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        .rview-scroll-list-input{
            position: relative;
            .rview-scroll-list-mulitiple-input{
                width: 100%;
                max-height: 72px;
                border: 1px solid #cccccc;
                border-radius: 4px;
                padding: 0 24px 10px 10px;
                overflow: auto;
                display: flex;
                justify-content: flex-start;
                align-items: center;
                flex-wrap: wrap;
                span.closeable{
                    padding: 5px 15px 5px 5px;
                    background: #cccccc;
                    color:#ffffff;
                    margin: 2px;
                    border-radius: 4px;
                    border: 1px solid #cccccc;
                    position: relative;
                    font-size: 12px;
                    &:hover{
                        box-shadow: 0 0 5px #cccccc;
                        color: #33aaff;
                        background: #ffffff;
                        border-color: #33aaff;
                        .close-btn{
                            background: #33aaff;
                        }
                    }
                    .close-btn{
                        position: absolute;
                        right: 0;
                        top: 0;
                        width: 10px;
                        height: 10px;
                        border-radius: 50%;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        overflow: hidden;
                        cursor: pointer;
                        border: 1px solid #ffffff;

                        &::before{
                            content: '';
                            width: 0;
                            height: 10px;
                            border-left: 2px solid #ffffff;
                            transform: rotate(-45deg) translate(1px);
                        }
                        &::after{
                            content: '';
                            height: 10px;
                            width: 0;
                            border-left: 2px solid #ffffff;
                            transform: rotate(45deg) translate(-1px);
                        }
                    }
                }
                input{
                    flex: 1;
                    border: 0;
                    outline: 0;
                    line-height: 36px;
                    height: 36px;
                    width: 50%;
                }
            }
            .rview-scroll-list-inner{
                width: 100%;
                height: 36px;
                line-height: 36px;
                border: 1px solid #cccccc;
                outline: 0;
                border-radius: 4px;
                padding: 5px 24px 10px 10px;
                &:hover{
                    border-color: #666666;
                }
                &:focus{
                    border-color: #33aaff;
                }
            }
            &.list-is-show .rview-scroll-list-direct{
                transform: rotate(180deg);
                color: #33aaff;
                &::before{
                  border-color: #33aaff;
                }
                &::after{
                  border-color: #33aaff;
                }
            }
            .rview-scroll-list-direct{
                position: absolute;
                right: 6px;
                top: 10px;
                width: 15px;
                height: 15px;
                font-size: 20px;
                transition: all 0.2s linear;
                color: #cccccc;
                display: flex;
                justify-content: center;
                align-items: center;
                &::before{
                  content: '';
                  display: block;
                  width: 10px;
                  height: 0;
                  transform-origin: center;
                  transform: rotate(45deg) translate(2px);
                  border-top: 2px solid #cccccc;
                }
                &::after{
                  content: '';
                  display: block;
                  width: 10px;
                  height: 0;
                  transform-origin: center;
                  transform: rotate(-45deg) translate(-2px);
                  border-top: 2px solid #cccccc;
                }
            }
        }
        .rview-scroll-list-options{
            position: absolute;
            left: 0;
            top: 40px;
            z-index: 99999;
            width: 100%;
            &.is-mulitiple{
                top: 78px;
            }
        }
    }
</style>
